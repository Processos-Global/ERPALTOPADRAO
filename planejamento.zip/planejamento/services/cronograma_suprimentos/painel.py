from __future__ import annotations

from django.db.models import Q
from django.utils import timezone

from planejamento.models.cronograma_suprimentos import (
    ImportacaoCronogramaSuprimentos,
)


def _situacao_contratada(situacao: str) -> bool:
    return "CONTRAT" in (situacao or "").upper()


def _item_contratado(item) -> bool:
    return bool(item.data_real_contratacao or _situacao_contratada(item.situacao))


def montar_painel_cronograma_suprimentos(
    *,
    obra_id=None,
    categoria: str = "",
    situacao: str = "",
    busca: str = "",
):
    importacao = (
        ImportacaoCronogramaSuprimentos.objects
        .filter(
            ativa=True,
            status=ImportacaoCronogramaSuprimentos.Status.CONCLUIDA,
        )
        .select_related("executado_por")
        .first()
    )

    if not importacao:
        return {
            "importacao_ativa": None,
            "obras": [],
            "cronograma_obra": None,
            "categorias": [],
            "categorias_filtro": [],
            "situacoes_filtro": [],
            "resumo": {
                "total": 0,
                "contratados": 0,
                "no_prazo": 0,
                "em_orcamento": 0,
                "atrasados": 0,
                "filtrados": 0,
            },
            "filtros": {
                "categoria": categoria,
                "situacao": situacao,
                "busca": busca,
            },
        }

    obras = list(
        importacao.obras_importadas
        .select_related("obra")
        .order_by("ordem_aba", "nome_aba")
    )

    selecionado = None
    if obra_id:
        selecionado = next(
            (x for x in obras if str(x.obra_id) == str(obra_id)),
            None,
        )
    if selecionado is None and obras:
        selecionado = obras[0]

    grupos = []
    categorias_filtro = []
    situacoes_filtro = []
    resumo = {
        "total": 0,
        "contratados": 0,
        "no_prazo": 0,
        "em_orcamento": 0,
        "atrasados": 0,
        "filtrados": 0,
    }

    if selecionado:
        todos_itens = list(
            selecionado.itens.all().order_by("ordem", "id")
        )

        categorias_filtro = sorted(
            {x.categoria for x in todos_itens if x.categoria},
            key=str.casefold,
        )
        situacoes_filtro = sorted(
            {x.situacao for x in todos_itens if x.situacao},
            key=str.casefold,
        )

        hoje = timezone.localdate()
        resumo["total"] = len(todos_itens)
        resumo["contratados"] = sum(
            1 for x in todos_itens if _item_contratado(x)
        )
        resumo["no_prazo"] = sum(
            1 for x in todos_itens if "NO PRAZO" in (x.situacao or "").upper()
        )
        resumo["em_orcamento"] = sum(
            1 for x in todos_itens if "ORCAMENTO" in (x.situacao or "").upper()
            or "ORÇAMENTO" in (x.situacao or "").upper()
        )
        resumo["atrasados"] = sum(
            1
            for x in todos_itens
            if x.prazo_limite_contratacao
            and x.prazo_limite_contratacao < hoje
            and not _item_contratado(x)
        )

        qs = selecionado.itens.all()
        if categoria:
            qs = qs.filter(categoria=categoria)
        if situacao:
            qs = qs.filter(situacao=situacao)
        if busca:
            qs = qs.filter(
                Q(item__icontains=busca)
                | Q(local__icontains=busca)
                | Q(contratada_responsavel__icontains=busca)
            )

        itens = list(qs.order_by("ordem", "id"))
        resumo["filtrados"] = len(itens)

        mapa = {}
        for item in itens:
            item.atrasado_calculado = bool(
                item.prazo_limite_contratacao
                and item.prazo_limite_contratacao < hoje
                and not _item_contratado(item)
            )
            nome_categoria = item.categoria or "SEM CATEGORIA"
            mapa.setdefault(nome_categoria, []).append(item)

        grupos = [
            {"nome": nome, "itens": itens_categoria}
            for nome, itens_categoria in mapa.items()
        ]

    return {
        "importacao_ativa": importacao,
        "obras": obras,
        "cronograma_obra": selecionado,
        "categorias": grupos,
        "categorias_filtro": categorias_filtro,
        "situacoes_filtro": situacoes_filtro,
        "resumo": resumo,
        "filtros": {
            "categoria": categoria,
            "situacao": situacao,
            "busca": busca,
        },
    }
