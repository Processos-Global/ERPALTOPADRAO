from django.conf import settings
from django.db import models


class ImportacaoCronogramaSuprimentos(models.Model):
    class Status(models.TextChoices):
        PROCESSANDO = "PROCESSANDO", "Processando"
        CONCLUIDA = "CONCLUIDA", "Concluída"
        FALHOU = "FALHOU", "Falhou"

    status = models.CharField(
        max_length=20,
        choices=Status.choices,
        default=Status.PROCESSANDO,
        db_index=True,
    )
    ativa = models.BooleanField(default=False, db_index=True)

    nome_arquivo = models.CharField(max_length=255, blank=True)
    arquivo_drive_id = models.CharField(max_length=255, blank=True, db_index=True)
    mime_type = models.CharField(max_length=255, blank=True)
    data_modificacao_drive = models.DateTimeField(null=True, blank=True)
    hash_arquivo = models.CharField(max_length=64, blank=True, db_index=True)
    tamanho_arquivo_bytes = models.BigIntegerField(default=0)

    total_abas_arquivo = models.PositiveIntegerField(default=0)
    abas_importadas = models.PositiveIntegerField(default=0)
    abas_ignoradas = models.PositiveIntegerField(default=0)
    total_itens_importados = models.PositiveIntegerField(default=0)

    mensagem = models.TextField(blank=True)
    erro_detalhado = models.TextField(blank=True)

    executado_por = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="importacoes_cronograma_suprimentos",
    )

    iniciou_em = models.DateTimeField(null=True, blank=True)
    finalizou_em = models.DateTimeField(null=True, blank=True)
    criado_em = models.DateTimeField(auto_now_add=True)
    atualizado_em = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ("-criado_em",)
        verbose_name = "Importação do cronograma de suprimentos"
        verbose_name_plural = "Importações do cronograma de suprimentos"
        indexes = [
            models.Index(fields=["ativa", "status"], name="plan_cs_imp_ativa_idx"),
            models.Index(fields=["hash_arquivo"], name="plan_cs_imp_hash_idx"),
        ]

    def __str__(self):
        estado = "ativa" if self.ativa else self.get_status_display()
        return f"{self.nome_arquivo or 'Cronograma de suprimentos'} - {estado}"


class CronogramaSuprimentosObra(models.Model):
    importacao = models.ForeignKey(
        ImportacaoCronogramaSuprimentos,
        on_delete=models.CASCADE,
        related_name="obras_importadas",
    )
    obra = models.ForeignKey(
        "obras.Obra",
        on_delete=models.PROTECT,
        related_name="cronogramas_suprimentos_importados",
    )
    nome_aba = models.CharField(max_length=255, db_index=True)
    codigo_aba = models.CharField(max_length=30, db_index=True)
    data_inicio_obra = models.DateField(null=True, blank=True)
    quantidade_itens = models.PositiveIntegerField(default=0)
    ordem_aba = models.PositiveIntegerField(default=0)
    criado_em = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("ordem_aba", "nome_aba")
        verbose_name = "Cronograma de suprimentos da obra"
        verbose_name_plural = "Cronogramas de suprimentos das obras"
        constraints = [
            models.UniqueConstraint(
                fields=["importacao", "obra"],
                name="plan_cs_imp_obra_unica",
            ),
            models.UniqueConstraint(
                fields=["importacao", "nome_aba"],
                name="plan_cs_imp_aba_unica",
            ),
        ]
        indexes = [
            models.Index(fields=["importacao", "obra"], name="plan_cs_imp_obra_idx"),
            models.Index(fields=["codigo_aba"], name="plan_cs_codigo_aba_idx"),
        ]

    def __str__(self):
        return f"{self.nome_aba} - {self.obra}"


class ItemCronogramaSuprimento(models.Model):
    cronograma_obra = models.ForeignKey(
        CronogramaSuprimentosObra,
        on_delete=models.CASCADE,
        related_name="itens",
    )

    categoria = models.CharField(max_length=120, blank=True, db_index=True)
    situacao = models.CharField(max_length=120, blank=True, db_index=True)

    data_cotacao = models.DateField(null=True, blank=True, db_index=True)
    duracao_cotacao = models.PositiveIntegerField(null=True, blank=True)

    data_compatibilizacao = models.DateField(null=True, blank=True)
    duracao_compatibilizacao = models.PositiveIntegerField(null=True, blank=True)

    data_negociacao = models.DateField(null=True, blank=True)
    duracao_negociacao = models.PositiveIntegerField(null=True, blank=True)

    prazo_limite_contratacao = models.DateField(null=True, blank=True, db_index=True)
    data_real_contratacao = models.DateField(null=True, blank=True, db_index=True)

    # Quando uma data for ajustada pela tela, preservamos o conjunto de datas
    # nas próximas importações do Drive para não perder o preenchimento manual.
    datas_editadas_manualmente = models.BooleanField(default=False, db_index=True)
    datas_editadas_por = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="itens_cronograma_suprimentos_editados",
    )
    datas_editadas_em = models.DateTimeField(null=True, blank=True)

    item = models.CharField(max_length=500, db_index=True)
    local = models.CharField(max_length=500, blank=True)
    contratada_responsavel = models.CharField(max_length=255, blank=True)
    dias_apos_inicio = models.IntegerField(null=True, blank=True)
    mes_referencia = models.CharField(max_length=50, blank=True)

    linha_origem = models.PositiveIntegerField(default=0)
    ordem = models.PositiveIntegerField(default=0)
    criado_em = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("cronograma_obra", "ordem", "id")
        verbose_name = "Item do cronograma de suprimentos"
        verbose_name_plural = "Itens do cronograma de suprimentos"
        indexes = [
            models.Index(
                fields=["cronograma_obra", "categoria"],
                name="plan_cs_item_cat_idx",
            ),
            models.Index(
                fields=["cronograma_obra", "situacao"],
                name="plan_cs_item_sit_idx",
            ),
            models.Index(
                fields=["cronograma_obra", "prazo_limite_contratacao"],
                name="plan_cs_item_prazo_idx",
            ),
        ]

    def __str__(self):
        return f"{self.cronograma_obra.nome_aba} - {self.item}"
