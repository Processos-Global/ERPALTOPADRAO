from datetime import date, timedelta
from decimal import Decimal

from django.db.models import Count, Sum
from django.db.models.functions import TruncMonth
from django.shortcuts import render
from django.utils import timezone
from django.utils.dateparse import parse_date

from cadastros.models import Fornecedor
from financeiro.models import Pagamento, PlanoFinanceiro, TituloPagar
from financeiro.services.permissoes import financeiro_acao_required
from obras.models import Obra


@financeiro_acao_required("VISUALIZAR")
def indicadores(request):
    hoje = timezone.localdate()
    inicio = parse_date((request.GET.get("inicio") or "").strip()) or date(hoje.year, 1, 1)
    fim = parse_date((request.GET.get("fim") or "").strip()) or hoje
    obra = (request.GET.get("obra") or "").strip()
    classe = (request.GET.get("classe") or "").strip()
    apropriacao = (request.GET.get("apropriacao") or "").strip()
    fornecedor = (request.GET.get("fornecedor") or "").strip()

    pagos = Pagamento.objects.filter(
        status=Pagamento.Status.EFETIVADO,
        data_pagamento__range=(inicio, fim),
    ).select_related(
        "titulo__obra", "titulo__fornecedor", "titulo__plano_financeiro", "titulo__plano_financeiro__pai"
    )
    titulos = TituloPagar.objects.exclude(
        status__in=[TituloPagar.Status.PAGO, TituloPagar.Status.CANCELADO]
    ).select_related("obra", "fornecedor", "plano_financeiro", "plano_financeiro__pai")

    def aplicar_filtros(qs, prefixo=""):
        if obra:
            qs = qs.filter(**{f"{prefixo}obra_id": obra})
        if fornecedor:
            qs = qs.filter(**{f"{prefixo}fornecedor_id": fornecedor})
        if apropriacao:
            qs = qs.filter(**{f"{prefixo}plano_financeiro_id": apropriacao})
        elif classe:
            qs = qs.filter(**{f"{prefixo}plano_financeiro__pai_id": classe})
        return qs

    pagos = aplicar_filtros(pagos, "titulo__")
    titulos = aplicar_filtros(titulos)

    total_pago = pagos.aggregate(total=Sum("valor"))["total"] or Decimal("0")
    quantidade_pagamentos = pagos.aggregate(total=Count("id"))["total"] or 0
    total_aberto = sum((titulo.saldo_aberto for titulo in titulos), Decimal("0"))
    media_pagamento = (total_pago / quantidade_pagamentos) if quantidade_pagamentos else Decimal("0")

    por_classe = list(
        pagos.exclude(titulo__plano_financeiro__pai__isnull=True)
        .values("titulo__plano_financeiro__pai__codigo", "titulo__plano_financeiro__pai__nome")
        .annotate(total=Sum("valor"), quantidade=Count("id"))
        .order_by("-total")
    )
    por_apropriacao = list(
        pagos.exclude(titulo__plano_financeiro__isnull=True)
        .values("titulo__plano_financeiro__codigo", "titulo__plano_financeiro__nome", "titulo__plano_financeiro__pai__nome")
        .annotate(total=Sum("valor"), quantidade=Count("id"))
        .order_by("-total")
    )
    por_obra = list(
        pagos.exclude(titulo__obra__isnull=True)
        .values("titulo__obra__id", "titulo__obra__nome")
        .annotate(total=Sum("valor"), quantidade=Count("id"))
        .order_by("-total")
    )
    por_fornecedor = list(
        pagos.exclude(titulo__fornecedor__isnull=True)
        .values("titulo__fornecedor__id", "titulo__fornecedor__nome")
        .annotate(total=Sum("valor"), quantidade=Count("id"))
        .order_by("-total")
    )
    por_mes = list(
        pagos.annotate(mes=TruncMonth("data_pagamento"))
        .values("mes")
        .annotate(total=Sum("valor"), quantidade=Count("id"))
        .order_by("mes")
    )

    return render(request, "financeiro/indicadores.html", {
        "inicio": inicio,
        "fim": fim,
        "filtros": {"obra": obra, "classe": classe, "apropriacao": apropriacao, "fornecedor": fornecedor},
        "obras": Obra.objects.all().order_by("id"),
        "fornecedores": Fornecedor.objects.filter(ativo=True).order_by("nome"),
        "classes_financeiras": PlanoFinanceiro.objects.filter(ativo=True, pai__isnull=True).order_by("codigo", "nome"),
        "apropriacoes": PlanoFinanceiro.objects.filter(ativo=True, pai__isnull=False).select_related("pai").order_by("pai__codigo", "codigo", "nome"),
        "total_pago": total_pago,
        "quantidade_pagamentos": quantidade_pagamentos,
        "total_aberto": total_aberto,
        "media_pagamento": media_pagamento,
        "por_classe": por_classe,
        "por_apropriacao": por_apropriacao,
        "por_obra": por_obra,
        "por_fornecedor": por_fornecedor,
        "por_mes": por_mes,
    })
