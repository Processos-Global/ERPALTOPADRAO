"""Consultas gerenciais somente leitura."""
